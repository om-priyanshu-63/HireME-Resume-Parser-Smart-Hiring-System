/**
 * HireME — Main Application Logic
 * Navigation • Dashboard • Candidates • Jobs • Analytics • History
 */

// ── State ───────────────────────────────────────────────────────
let currentUser = null;
let allJobs     = [];
let allResumes  = [];
let sortKey     = 'matching_score';
let sortAsc     = false;
let editingJobId = null;

// ── Bootstrap ───────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  initNavigation();
  initUpload();
  initSkillInput();

  await checkAuth();         // login (auto if needed)
  await Promise.all([
    loadJobs(),
    loadDashboard(),
  ]);
  updateBadges();

  // Seed demo button
  document.getElementById('seedDemoBtn').addEventListener('click', seedDemoData);
});

// ── Auth ────────────────────────────────────────────────────────
async function checkAuth() {
  try {
    const data = await apiMe();
    if (data.user) {
      setUserUI(data.user);
      return;
    }
    // Auto-login for demo / dev
    const login = await apiLogin('admin', 'admin123');
    if (login.user) setUserUI(login.user);
  } catch (e) {
    console.warn('Auth:', e);
  }
}

function setUserUI(user) {
  currentUser = user;
  document.getElementById('userName').textContent   = user.username;
  document.getElementById('userRole').textContent   = user.role;
  document.getElementById('userAvatar').textContent = user.username[0].toUpperCase();
}

document.getElementById('logoutBtn').addEventListener('click', async () => {
  await apiLogout();
  showToast('Logged out.', 'success');
  setTimeout(() => window.location.href = '/login', 800);
});

// ── Navigation ──────────────────────────────────────────────────
const PAGE_META = {
  dashboard:   ['Dashboard',          "Welcome back! Here's your hiring overview."],
  upload:      ['Upload Resumes',     'Upload and parse resumes with AI-powered NLP.'],
  candidates:  ['All Candidates',     'Manage, sort and shortlist candidates.'],
  jobs:        ['Job Roles',          'Create job descriptions to match against resumes.'],
  shortlisted: ['Shortlisted',        'Candidates approved for the next round.'],
  rejected:    ['Rejected',           'Candidates that did not meet requirements.'],
  analytics:   ['Analytics',          'Deep insights into your hiring pipeline.'],
  history:     ['History',            'Full archive of all processed resumes.'],
};

function initNavigation() {
  document.querySelectorAll('.nav-item[data-page]').forEach(item => {
    item.addEventListener('click', () => showPage(item.dataset.page));
  });

  const menuBtn = document.getElementById('menuToggle');
  menuBtn.addEventListener('click', () =>
    document.getElementById('sidebar').classList.toggle('mobile-open')
  );

  // Responsive menu toggle visibility
  const checkMobile = () => {
    menuBtn.style.display = window.innerWidth <= 768 ? 'flex' : 'none';
  };
  window.addEventListener('resize', checkMobile);
  checkMobile();
}

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  const page = document.getElementById(`page-${pageId}`);
  const nav  = document.getElementById(`nav-${pageId}`);
  if (page) page.classList.add('active');
  if (nav)  nav.classList.add('active');

  const [title, subtitle] = PAGE_META[pageId] || [pageId, ''];
  document.getElementById('pageTitle').textContent    = title;
  document.getElementById('pageSubtitle').textContent = subtitle;

  // Lazy-load page data
  const loaders = {
    dashboard:   loadDashboard,
    candidates:  loadCandidates,
    jobs:        renderJobsList,
    shortlisted: () => loadStatusPage('shortlisted'),
    rejected:    () => loadStatusPage('rejected'),
    analytics:   loadAnalytics,
    history:     loadHistory,
  };
  loaders[pageId]?.();

  document.getElementById('sidebar').classList.remove('mobile-open');
}

// ── Dashboard ───────────────────────────────────────────────────
async function loadDashboard() {
  try {
    const [summary, dist, skills, funnel] = await Promise.all([
      apiGetSummary(), apiGetScoreDistribution(), apiGetTopSkills(), apiGetHiringFunnel(),
    ]);

    animateStatValue('stat-total',       summary.total_resumes   ?? 0);
    animateStatValue('stat-shortlisted', summary.shortlisted      ?? 0);
    animateStatValue('stat-rejected',    summary.rejected         ?? 0);
    animateStatValue('stat-pending',     summary.pending          ?? 0);
    document.getElementById('stat-avg-score').textContent = (summary.avg_matching_score ?? 0) + '%';
    animateStatValue('stat-jobs', summary.total_jobs ?? 0);

    renderStatusChart(summary);
    renderScoreDistChart(dist.distribution || {});
    renderSkillsChart((skills.skills || []).slice(0, 12));
    renderFunnelChart(funnel.stages || [], 'funnelChart');
  } catch (e) {
    console.error('Dashboard error:', e);
  }
}

function animateStatValue(id, target) {
  const el = document.getElementById(id);
  if (!el) return;
  const start = parseInt(el.textContent) || 0;
  if (start === target) return;
  const duration = 600;
  const startTime = Date.now();
  const frame = () => {
    const pct = Math.min((Date.now() - startTime) / duration, 1);
    el.textContent = Math.round(start + (target - start) * easeOut(pct));
    if (pct < 1) requestAnimationFrame(frame);
  };
  requestAnimationFrame(frame);
}
const easeOut = t => 1 - Math.pow(1 - t, 3);

// ── Jobs ────────────────────────────────────────────────────────
async function loadJobs() {
  try {
    const data = await apiGetJobs();
    allJobs = data.jobs || [];
    populateJobDropdowns();
  } catch (e) {
    console.error('Jobs error:', e);
  }
}

function populateJobDropdowns() {
  ['uploadJobSelect', 'filterJob'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    const prev = el.value;
    el.innerHTML = id === 'uploadJobSelect'
      ? '<option value="">— Select a job role for matching —</option>'
      : '<option value="">All Jobs</option>';
    allJobs.forEach(j => {
      const o = document.createElement('option');
      o.value = j.id; o.textContent = j.title;
      el.appendChild(o);
    });
    el.value = prev;
  });
}

function renderJobsList() {
  const container = document.getElementById('jobsList');
  if (!allJobs.length) {
    container.innerHTML = `<div class="empty-state col-span-all">
      <span class="empty-icon"><i class="ri-briefcase-line"></i></span>
      <h3>No job roles yet</h3>
      <p>Click "Create New Job" to define a role and start matching resumes.</p>
    </div>`;
    return;
  }
  container.innerHTML = allJobs.map(j => {
    const chips = j.required_skills.slice(0, 5)
      .map(s => `<span class="skill-chip neutral">${esc(s)}</span>`).join('');
    const more = j.required_skills.length > 5
      ? `<span class="skill-chip neutral">+${j.required_skills.length - 5}</span>` : '';
    return `<div class="job-card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:10px">
        <div>
          <div style="font-size:16px;font-weight:700">${esc(j.title)}</div>
          <div style="font-size:11px;color:var(--text-muted);margin-top:2px">
            <i class="ri-calendar-line"></i> ${fmt(j.created_at)}${j.min_experience > 0 ? ` &nbsp;·&nbsp; <i class="ri-briefcase-line"></i> ${j.min_experience}+ yrs` : ''}
          </div>
        </div>
        <div style="display:flex;gap:5px;flex-shrink:0">
          <button class="btn btn-secondary btn-sm" onclick="editJob(${j.id})"><i class="ri-edit-line"></i></button>
          <button class="btn btn-danger btn-sm" onclick="deleteJob(${j.id})"><i class="ri-delete-bin-6-line"></i></button>
        </div>
      </div>
      <p style="font-size:12px;color:var(--text-muted);margin-bottom:10px;line-height:1.55">
        ${esc(j.description.slice(0, 130))}${j.description.length > 130 ? '…' : ''}
      </p>
      <div class="skill-chips" style="margin-bottom:12px">${chips}${more}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn btn-primary btn-sm"
          onclick="showPage('upload');setTimeout(()=>{ document.getElementById('uploadJobSelect').value='${j.id}';},80)">
          <i class="ri-upload-cloud-2-line"></i> Upload Resumes
        </button>
        <button class="btn btn-secondary btn-sm" onclick="filterCandidatesByJob(${j.id})">
          <i class="ri-team-line"></i> View Candidates
        </button>
      </div>
    </div>`;
  }).join('');
}

// ── Job Modal ────────────────────────────────────────────────────
let jobSkills = [];

function openJobModal(job = null) {
  editingJobId = job ? job.id : null;
  jobSkills = job ? [...job.required_skills] : [];
  document.getElementById('jobModalTitle').innerHTML = job ? '<i class="ri-edit-line"></i> Edit Job Role' : '<i class="ri-add-line"></i> Create Job Role';
  document.getElementById('jobTitle').value       = job?.title       || '';
  document.getElementById('jobDescription').value = job?.description || '';
  document.getElementById('jobMinExp').value       = job?.min_experience ?? 0;
  renderSkillTags();
  openModal('jobModal');
  setTimeout(() => document.getElementById('jobTitle').focus(), 150);
}

function editJob(id) {
  const j = allJobs.find(j => j.id === id);
  if (j) openJobModal(j);
}

async function deleteJob(id) {
  if (!confirm('Delete this job role? Existing candidate links will be preserved.')) return;
  showLoading('Deleting job...');
  const data = await apiDeleteJob(id);
  hideLoading();
  if (data.message) {
    showToast('Job deleted.', 'success');
    await loadJobs(); renderJobsList(); updateBadges();
  } else {
    showToast(data.error || 'Delete failed.', 'error');
  }
}

async function saveJob() {
  const title       = document.getElementById('jobTitle').value.trim();
  const description = document.getElementById('jobDescription').value.trim();
  const minExp      = parseFloat(document.getElementById('jobMinExp').value) || 0;

  if (!title)       { showToast('Job title is required.', 'error'); return; }
  if (!description) { showToast('Job description is required.', 'error'); return; }

  const payload = { title, description, required_skills: jobSkills, min_experience: minExp };
  showLoading(editingJobId ? 'Updating job...' : 'Creating job...');
  const data = editingJobId
    ? await apiUpdateJob(editingJobId, payload)
    : await apiCreateJob(payload);
  hideLoading();

  if (data.error) { showToast(data.error, 'error'); return; }
  showToast(editingJobId ? 'Job updated!' : 'Job created!', 'success');
  closeModal('jobModal');
  await loadJobs(); renderJobsList(); updateBadges();
}

// ── Skill Tags ───────────────────────────────────────────────────
function initSkillInput() {
  const input = document.getElementById('skillInput');
  if (!input) return;
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const val = input.value.trim().replace(/,$/, '').toLowerCase();
      if (val && !jobSkills.map(s => s.toLowerCase()).includes(val)) {
        jobSkills.push(val);
        renderSkillTags();
      }
      input.value = '';
    }
    if (e.key === 'Backspace' && !input.value && jobSkills.length) {
      jobSkills.pop(); renderSkillTags();
    }
  });
}

function renderSkillTags() {
  document.getElementById('skillTagsContainer').innerHTML =
    jobSkills.map((s, i) => `
      <span class="skill-tag">${esc(s)}
        <span class="remove-tag" onclick="removeSkillTag(${i})"><i class="ri-close-line"></i></span>
      </span>`).join('');
}

function removeSkillTag(i) { jobSkills.splice(i, 1); renderSkillTags(); }

// ── Candidates Table ─────────────────────────────────────────────
async function loadCandidates() {
  try {
    const data = await apiGetResumes();
    allResumes = data.resumes || [];
    filterCandidates();
  } catch (e) { console.error('Candidates error:', e); }
}

function renderCandidatesTable(resumes) {
  const tbody = document.getElementById('candidatesBody');
  const countEl = document.getElementById('candidatesCount');
  if (countEl) countEl.textContent = `${resumes.length} candidate${resumes.length !== 1 ? 's' : ''}`;

  if (!resumes.length) {
    tbody.innerHTML = `<tr><td colspan="8" style="padding:0">
      <div class="empty-state">
        <span class="empty-icon"><i class="ri-inbox-line"></i></span>
        <h3>No candidates match your filters</h3>
        <p>Try adjusting the filters or upload new resumes.</p>
      </div></td></tr>`;
    return;
  }
  tbody.innerHTML = resumes.map(r => {
    const skills = r.skills.slice(0, 4).map(s =>
      `<span class="skill-chip neutral">${esc(s)}</span>`).join('');
    const extra = r.skills.length > 4 ? `<span class="skill-chip neutral">+${r.skills.length - 4}</span>` : '';
    const scoreCls = r.matching_score >= 70 ? 'green' : r.matching_score >= 40 ? 'orange' : 'red';
    return `<tr>
      <td>
        <div style="font-weight:600">${esc(r.candidate_name || '—')}</div>
        <div class="truncate text-sm text-muted" style="max-width:140px">${esc(r.filename)}</div>
      </td>
      <td>
        ${r.email ? `<div class="text-sm"><i class="ri-mail-line"></i> ${esc(r.email)}</div>` : '<span class="text-muted">—</span>'}
        ${r.phone ? `<div class="text-sm text-muted"><i class="ri-phone-line"></i> ${esc(r.phone)}</div>` : ''}
      </td>
      <td>
        ${scoreRing(r.matching_score)}
        <div style="margin-top:4px;width:72px">
          <div class="progress-bar-wrap" style="height:3px">
            <div class="progress-bar ${scoreCls}" style="width:${r.matching_score}%;transition:none"></div>
          </div>
        </div>
      </td>
      <td><span class="star-rating">${stars(r.matching_score)}</span></td>
      <td><div class="skill-chips">${skills}${extra}</div></td>
      <td class="text-sm">${r.experience_years ? r.experience_years + ' yrs' : '—'}</td>
      <td><span class="status-badge status-${r.status}">${r.status}</span></td>
      <td>
        <div style="display:flex;gap:3px;flex-wrap:nowrap">
          <button class="btn btn-secondary btn-sm" onclick="viewResume(${r.id})" title="View Profile"><i class="ri-eye-line"></i></button>
          ${r.status !== 'shortlisted' ? `<button class="btn btn-success btn-sm" onclick="updateStatus(${r.id},'shortlisted')" title="Shortlist"><i class="ri-check-line"></i></button>` : ''}
          ${r.status !== 'rejected'    ? `<button class="btn btn-danger btn-sm"  onclick="updateStatus(${r.id},'rejected')"    title="Reject"><i class="ri-close-line"></i></button>` : ''}
          ${r.status !== 'pending'     ? `<button class="btn btn-secondary btn-sm" onclick="updateStatus(${r.id},'pending')"   title="Reset"><i class="ri-arrow-go-back-line"></i></button>` : ''}
          <button class="btn btn-secondary btn-sm" onclick="deleteCandidate(${r.id})" title="Delete"><i class="ri-delete-bin-6-line"></i></button>
        </div>
      </td>
    </tr>`;
  }).join('');
}

function filterCandidates() {
  const search = document.getElementById('candidateSearch')?.value.toLowerCase() || '';
  const jobId  = document.getElementById('filterJob')?.value || '';
  const status = document.getElementById('filterStatus')?.value || '';
  const score  = document.getElementById('filterScore')?.value || '';

  const filtered = allResumes.filter(r => {
    const okSearch = !search
      || (r.candidate_name || '').toLowerCase().includes(search)
      || (r.email || '').toLowerCase().includes(search);
    const okJob   = !jobId   || String(r.job_id) === jobId;
    const okStat  = !status  || r.status === status;
    const okScore = !score
      || (score === 'high' && r.matching_score >= 70)
      || (score === 'mid'  && r.matching_score >= 40 && r.matching_score < 70)
      || (score === 'low'  && r.matching_score < 40);
    return okSearch && okJob && okStat && okScore;
  });
  renderCandidatesTable(filtered);
}

function filterCandidatesByJob(jobId) {
  showPage('candidates');
  setTimeout(() => {
    document.getElementById('filterJob').value = String(jobId);
    filterCandidates();
  }, 120);
}

function sortTable(key) {
  // Toggle direction
  if (sortKey === key) sortAsc = !sortAsc;
  else { sortKey = key; sortAsc = false; }

  // Update header arrows
  document.querySelectorAll('thead th.sorted').forEach(th => th.classList.remove('sorted'));
  document.querySelectorAll('thead th.sortable').forEach(th => {
    if (th.getAttribute('onclick')?.includes(key)) {
      th.classList.add('sorted');
      const arrow = th.querySelector('.sort-arrow');
      if (arrow) arrow.textContent = sortAsc ? '↑' : '↓';
    }
  });

  const sorted = [...allResumes].sort((a, b) => {
    const av = a[key] ?? '', bv = b[key] ?? '';
    if (typeof av === 'number') return sortAsc ? av - bv : bv - av;
    return sortAsc
      ? String(av).localeCompare(String(bv))
      : String(bv).localeCompare(String(av));
  });
  renderCandidatesTable(sorted);
}

async function updateStatus(id, status) {
  const data = await apiUpdateStatus(id, status);
  if (data.resume) {
    const idx = allResumes.findIndex(r => r.id === id);
    if (idx !== -1) allResumes[idx] = data.resume;
    filterCandidates();
    updateBadges();
    showToast(`Marked as ${status}.`, status === 'shortlisted' ? 'success' : status === 'rejected' ? 'error' : 'info');
    // Refresh status pages if visible
    const active = document.querySelector('.page.active')?.id;
    if (active === 'page-shortlisted') loadStatusPage('shortlisted');
    if (active === 'page-rejected')    loadStatusPage('rejected');
  }
}

async function deleteCandidate(id) {
  if (!confirm('Permanently delete this resume?')) return;
  showLoading('Deleting...');
  const data = await apiDeleteResume(id);
  hideLoading();
  if (data.message) {
    allResumes = allResumes.filter(r => r.id !== id);
    filterCandidates(); updateBadges();
    showToast('Resume deleted.', 'success');
  }
}

// ── Resume Detail Modal ──────────────────────────────────────────
async function viewResume(id) {
  showLoading('Loading candidate profile...');
  let data;
  try { data = await apiGetResume(id); } catch(e) { hideLoading(); showToast('Failed to load.','error'); return; }
  hideLoading();

  const r       = data.resume;
  const job     = r.job;
  const matched = r.matched_skills || [];
  const missing = r.missing_skills || [];

  document.getElementById('resumeModalTitle').innerHTML = `<i class="ri-user-line"></i> ${esc(r.candidate_name || 'Candidate Profile')}`;

  const skillChips = r.skills.map(s =>
    `<span class="skill-chip ${matched.includes(s) ? 'matched' : 'neutral'}">${esc(s)}</span>`
  ).join('');

  const eduRows = r.education.length
    ? r.education.map(e => `<div class="edu-row">${esc(e)}</div>`).join('')
    : '<p class="text-muted text-sm">Not found in resume.</p>';

  const expRows = r.experience_details.length
    ? r.experience_details.slice(0, 6).map(e => `<div class="edu-row">${esc(e)}</div>`).join('')
    : '<p class="text-muted text-sm">Not found in resume.</p>';

  const suggHTML = r.improvement_suggestions.length
    ? `<ul class="suggestions-list">${r.improvement_suggestions.map(s => `<li>${esc(s)}</li>`).join('')}</ul>`
    : '<p class="text-muted text-sm">No suggestions at this time.</p>';

  const matchSection = job ? `
    <div class="card mb-16">
      <div style="font-size:13px;font-weight:700;margin-bottom:10px"><i class="ri-focus-3-line"></i> Job Match: ${esc(job.title)}</div>
      ${matched.length ? `
        <div style="margin-bottom:8px">
          <div class="text-sm" style="color:var(--success);font-weight:600;margin-bottom:4px"><i class="ri-checkbox-circle-line"></i> Matched (${matched.length})</div>
          <div class="skill-chips">${matched.map(s => `<span class="skill-chip matched">${esc(s)}</span>`).join('')}</div>
        </div>` : ''}
      ${missing.length ? `
        <div>
          <div class="text-sm" style="color:var(--danger);font-weight:600;margin-bottom:4px"><i class="ri-close-circle-line"></i> Missing (${missing.length})</div>
          <div class="skill-chips">${missing.map(s => `<span class="skill-chip missing">${esc(s)}</span>`).join('')}</div>
        </div>` : ''}
    </div>` : '';

  document.getElementById('resumeModalContent').innerHTML = `
    <!-- header row -->
    <div style="display:flex;gap:14px;align-items:center;margin-bottom:20px;padding:16px;background:var(--bg-surface);border-radius:var(--radius);border:1px solid var(--border)">
      <div style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:700;flex-shrink:0">
        ${(r.candidate_name || '?')[0].toUpperCase()}
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-size:20px;font-weight:700">${esc(r.candidate_name || 'Unknown')}</div>
        <div class="text-sm text-muted" style="display:flex;gap:12px;flex-wrap:wrap;margin-top:4px">
          ${r.email ? `<span><i class="ri-mail-line"></i> ${esc(r.email)}</span>` : ''}
          ${r.phone ? `<span><i class="ri-phone-line"></i> ${esc(r.phone)}</span>` : ''}
          ${r.experience_years ? `<span><i class="ri-briefcase-line"></i> ${r.experience_years} yrs exp</span>` : ''}
        </div>
      </div>
      <div style="text-align:center;flex-shrink:0">
        <div style="font-size:28px;font-weight:800;color:var(--accent)">${r.matching_score}%</div>
        <div class="star-rating">${stars(r.matching_score)}</div>
        <div style="margin-top:4px"><span class="status-badge status-${r.status}">${r.status}</span></div>
      </div>
    </div>

    <!-- 2-column body -->
    <div class="profile-grid">
      <div>
        <div class="card mb-16">
          <div style="font-size:13px;font-weight:700;margin-bottom:10px"><i class="ri-tools-line"></i> Skills (${r.skills.length})</div>
          <div class="skill-chips">${skillChips || '<span class="text-muted text-sm">None found</span>'}</div>
        </div>
        <div class="card mb-16">
          <div style="font-size:13px;font-weight:700;margin-bottom:10px"><i class="ri-graduation-cap-line"></i> Education</div>
          ${eduRows}
        </div>
        <div class="card">
          <div style="font-size:13px;font-weight:700;margin-bottom:10px"><i class="ri-briefcase-line"></i> Experience</div>
          ${expRows}
        </div>
      </div>
      <div>
        ${matchSection}
        <div class="card mb-16">
          <div style="font-size:13px;font-weight:700;margin-bottom:10px"><i class="ri-lightbulb-line"></i> Improvement Suggestions</div>
          ${suggHTML}
        </div>
        <div class="card">
          <div style="font-size:13px;font-weight:700;margin-bottom:10px"><i class="ri-file-text-line"></i> Resume Info</div>
          <div class="text-sm text-muted" style="display:flex;flex-direction:column;gap:6px">
            <span><i class="ri-folder-line"></i> ${esc(r.filename)}</span>
            <span><i class="ri-calendar-line"></i> Uploaded: ${new Date(r.uploaded_at).toLocaleString()}</span>
            ${r.job ? `<span><i class="ri-briefcase-line"></i> Job: ${esc(r.job.title)}</span>` : ''}
          </div>
          ${r.raw_text ? `
          <button class="btn btn-secondary btn-sm w-full" style="margin-top:12px"
            onclick="closeModal('resumeModal');previewResumeText(${r.id},'${esc(r.candidate_name || 'Resume')}')">
            <i class="ri-file-text-line"></i> View Raw Text
          </button>` : ''}
        </div>
      </div>
    </div>

    <!-- action buttons -->
    <div style="display:flex;gap:8px;margin-top:16px;justify-content:flex-end;flex-wrap:wrap">
      ${r.status !== 'shortlisted' ? `<button class="btn btn-success" onclick="updateStatus(${r.id},'shortlisted');closeModal('resumeModal')"><i class="ri-check-line"></i> Shortlist</button>` : ''}
      ${r.status !== 'rejected'    ? `<button class="btn btn-danger"  onclick="updateStatus(${r.id},'rejected');closeModal('resumeModal')"><i class="ri-close-line"></i> Reject</button>` : ''}
      ${r.status !== 'pending'     ? `<button class="btn btn-secondary" onclick="updateStatus(${r.id},'pending');closeModal('resumeModal')"><i class="ri-arrow-go-back-line"></i> Reset</button>` : ''}
    </div>`;

  // Add edu-row style inline
  document.querySelectorAll('.edu-row').forEach(el => {
    el.style.cssText = 'font-size:12px;color:var(--text-secondary);padding:5px 0;border-bottom:1px solid var(--border)';
    el.style.lineHeight = '1.5';
  });

  openModal('resumeModal');
}

// ── Resume Text Preview ──────────────────────────────────────────
async function previewResumeText(id, name) {
  showLoading('Loading text...');
  const data = await apiGetResume(id);
  hideLoading();
  const r = data.resume;
  if (!r?.raw_text) { showToast('No extracted text available.', 'warning'); return; }

  document.getElementById('previewModalTitle').innerHTML = `<i class="ri-file-text-line"></i> ${esc(name)} — Text Preview`;
  document.getElementById('previewModalContent').innerHTML =
    `<pre>${esc(r.raw_text)}</pre>`;
  openModal('previewModal');
}

// ── Status Pages ─────────────────────────────────────────────────
async function loadStatusPage(status) {
  const data = await apiGetResumes({ status });
  const resumes = data.resumes || [];
  const bodyId = status === 'shortlisted' ? 'shortlistedBody' : 'rejectedBody';
  const cols   = status === 'shortlisted' ? 6 : 5;
  const tbody  = document.getElementById(bodyId);

  if (!resumes.length) {
    tbody.innerHTML = `<tr><td colspan="${cols}" style="padding:0">
      <div class="empty-state">
        <span class="empty-icon"><i class="${status === 'shortlisted' ? 'ri-clipboard-line' : 'ri-folder-open-line'}"></i></span>
        <h3>No ${status} candidates</h3>
        <p>Update candidate status from the Candidates page.</p>
      </div></td></tr>`;
    return;
  }

  tbody.innerHTML = resumes.map(r => {
    const skills = r.skills.slice(0, 3).map(s => `<span class="skill-chip neutral">${esc(s)}</span>`).join('');
    const job    = allJobs.find(j => j.id === r.job_id);
    if (status === 'shortlisted') return `
      <tr>
        <td><div style="font-weight:600">${esc(r.candidate_name || '—')}</div></td>
        <td class="text-sm">${r.email ? esc(r.email) : '—'}</td>
        <td>${scoreRing(r.matching_score)}</td>
        <td><div class="skill-chips">${skills}</div></td>
        <td class="text-sm">${job ? esc(job.title) : '—'}</td>
        <td><div style="display:flex;gap:4px">
          <button class="btn btn-secondary btn-sm" onclick="viewResume(${r.id})"><i class="ri-eye-line"></i></button>
          <button class="btn btn-danger btn-sm" onclick="updateStatus(${r.id},'rejected')"><i class="ri-close-line"></i></button>
        </div></td>
      </tr>`;
    return `
      <tr>
        <td><div style="font-weight:600">${esc(r.candidate_name || '—')}</div></td>
        <td class="text-sm">${r.email ? esc(r.email) : '—'}</td>
        <td>${scoreRing(r.matching_score)}</td>
        <td class="text-sm">${job ? esc(job.title) : '—'}</td>
        <td><div style="display:flex;gap:4px">
          <button class="btn btn-secondary btn-sm" onclick="viewResume(${r.id})"><i class="ri-eye-line"></i></button>
          <button class="btn btn-success btn-sm" onclick="updateStatus(${r.id},'shortlisted')"><i class="ri-check-line"></i></button>
        </div></td>
      </tr>`;
  }).join('');
}

// ── Analytics ────────────────────────────────────────────────────
async function loadAnalytics() {
  try {
    const [summary, funnel, skills, jobScores] = await Promise.all([
      apiGetSummary(), apiGetHiringFunnel(), apiGetTopSkills(), apiGetScoreByJob(),
    ]);

    document.getElementById('an-avg-score').textContent  = (summary.avg_matching_score ?? 0) + '%';
    document.getElementById('an-shortlisted').textContent = summary.shortlisted ?? 0;
    document.getElementById('an-rejected').textContent    = summary.rejected    ?? 0;
    document.getElementById('an-total').textContent       = summary.total_resumes ?? 0;

    renderFunnelChart(funnel.stages || [], 'analyticsFunnelChart');
    renderSkillsChart((skills.skills || []).slice(0, 15), 'analyticsSkillsChart');
    renderJobScoreChart(jobScores.jobs || []);
  } catch (e) { console.error('Analytics error:', e); }
}

// ── History ──────────────────────────────────────────────────────
let historyCache = [];

async function loadHistory() {
  try {
    const data = await apiGetResumes();
    historyCache = data.resumes || [];
    filterHistory();
  } catch (e) { console.error('History error:', e); }
}

function filterHistory() {
  const search = document.getElementById('historySearch')?.value.toLowerCase() || '';
  const status = document.getElementById('historyFilterStatus')?.value || '';
  const date   = document.getElementById('historyDateFilter')?.value || '';

  const filtered = historyCache.filter(r => {
    const okSearch = !search || (r.candidate_name||'').toLowerCase().includes(search) || (r.email||'').toLowerCase().includes(search);
    const okStatus = !status || r.status === status;
    const okDate   = !date   || r.uploaded_at.startsWith(date);
    return okSearch && okStatus && okDate;
  });
  renderHistoryTable(filtered);
}

function renderHistoryTable(resumes) {
  const tbody = document.getElementById('historyBody');
  if (!resumes.length) {
    tbody.innerHTML = `<tr><td colspan="7" style="padding:0">
      <div class="empty-state">
        <span class="empty-icon"><i class="ri-time-line"></i></span>
        <h3>No history</h3>
        <p>Upload resumes to see records here.</p>
      </div></td></tr>`;
    return;
  }
  tbody.innerHTML = resumes.map(r => {
    const job = allJobs.find(j => j.id === r.job_id);
    return `<tr>
      <td>
        <div style="font-weight:600">${esc(r.candidate_name || '—')}</div>
        <div class="text-sm text-muted truncate" style="max-width:130px">${esc(r.filename)}</div>
      </td>
      <td class="text-sm">${r.email ? esc(r.email) : '—'}</td>
      <td>${scoreRing(r.matching_score)}</td>
      <td><span class="status-badge status-${r.status}">${r.status}</span></td>
      <td class="text-sm">${job ? esc(job.title) : '—'}</td>
      <td class="text-sm text-muted">${fmtFull(r.uploaded_at)}</td>
      <td>
        <div style="display:flex;gap:4px">
          <button class="btn btn-secondary btn-sm" onclick="viewResume(${r.id})"><i class="ri-eye-line"></i></button>
          <button class="btn btn-secondary btn-sm" onclick="deleteCandidate(${r.id})" title="Delete"><i class="ri-delete-bin-6-line"></i></button>
        </div>
      </td>
    </tr>`;
  }).join('');
}

// ── Badges ────────────────────────────────────────────────────────
async function updateBadges() {
  try {
    const data = await apiGetSummary();
    document.getElementById('badge-candidates').textContent  = data.total_resumes ?? 0;
    document.getElementById('badge-jobs').textContent        = data.total_jobs    ?? 0;
    document.getElementById('badge-shortlisted').textContent = data.shortlisted   ?? 0;
    document.getElementById('badge-rejected').textContent    = data.rejected      ?? 0;
  } catch (_) {}
}

// ── Demo Data ─────────────────────────────────────────────────────
async function seedDemoData() {
  showLoading('Loading demo data...');
  try {
    const res = await fetch('/api/seed-demo', { method: 'POST', credentials: 'include' });
    const data = await res.json();
    hideLoading();
    showToast(data.message || 'Demo data loaded!', 'success');
    await loadJobs();
    await loadDashboard();
    updateBadges();
  } catch (e) {
    hideLoading();
    showToast('Failed to load demo data.', 'error');
  }
}

// ── Modals ────────────────────────────────────────────────────────
function openModal(id) {
  document.getElementById(id).classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
  document.body.style.overflow = '';
}
document.querySelectorAll('.modal-overlay').forEach(o => {
  o.addEventListener('click', e => { if (e.target === o) closeModal(o.id); });
});
// Keyboard close
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(o => closeModal(o.id));
  }
  if (e.key === 'Enter' && document.getElementById('jobModal').classList.contains('open')) {
    // Allow Enter in textarea
    if (document.activeElement.tagName !== 'TEXTAREA') saveJob();
  }
});

// ── Toast ─────────────────────────────────────────────────────────
function showToast(message, type = 'info') {
  const icons = {
    success: '<i class="ri-checkbox-circle-fill"></i>',
    error:   '<i class="ri-close-circle-fill"></i>',
    warning: '<i class="ri-error-warning-fill"></i>',
    info:    '<i class="ri-information-fill"></i>',
  };
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<span>${icons[type] || icons.info}</span><span>${esc(String(message))}</span>`;
  document.getElementById('toast-container').appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateX(16px)'; t.style.transition = '0.3s'; }, 3500);
  setTimeout(() => t.remove(), 3900);
}

// ── Loading ───────────────────────────────────────────────────────
function showLoading(text = 'Processing...') {
  document.getElementById('loadingText').textContent = text;
  document.getElementById('loadingOverlay').style.display = 'flex';
}
function hideLoading() {
  document.getElementById('loadingOverlay').style.display = 'none';
}

// ── Utilities ─────────────────────────────────────────────────────
function esc(str) {
  return String(str ?? '')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#x27;');
}
function fmt(isoStr)  { return isoStr ? new Date(isoStr).toLocaleDateString() : '—'; }
function fmtFull(iso) { return iso ? new Date(iso).toLocaleString() : '—'; }

function scoreRing(score) {
  const cls = score >= 70 ? 'score-high' : score >= 40 ? 'score-mid' : score > 0 ? 'score-low' : 'score-zero';
  return `<span class="score-badge ${cls}">${score}%</span>`;
}
function stars(score) {
  const n = Math.round((score / 100) * 5);
  return '★'.repeat(n) + '☆'.repeat(5 - n);
}
