/**
 * HireME — Upload Module
 * Drag & drop, file validation, progress, results display
 */

let selectedFiles = [];

function initUpload() {
  const dropZone = document.getElementById('dropZone');
  const fileInput = document.getElementById('fileInput');

  if (!dropZone) return;  // not on upload page

  // Click to browse
  dropZone.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', e => {
    addFiles(Array.from(e.target.files));
    fileInput.value = '';
  });

  // Drag-and-drop
  ['dragenter','dragover'].forEach(ev =>
    dropZone.addEventListener(ev, e => { e.preventDefault(); dropZone.classList.add('drag-over'); })
  );
  ['dragleave','dragend'].forEach(ev =>
    dropZone.addEventListener(ev, () => dropZone.classList.remove('drag-over'))
  );
  dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
    addFiles(Array.from(e.dataTransfer.files));
  });

  // Buttons
  document.getElementById('uploadBtn').addEventListener('click', handleUpload);
  document.getElementById('clearFilesBtn').addEventListener('click', clearFiles);
}

// ── File management ──────────────────────────────────────────────
const ALLOWED = /\.(pdf|docx|txt)$/i;

function isAllowed(file) { return ALLOWED.test(file.name); }

function addFiles(files) {
  const ok  = files.filter(isAllowed);
  const bad = files.filter(f => !isAllowed(f));
  if (bad.length)
    showToast(`${bad.length} file(s) skipped — only PDF, DOCX, TXT allowed.`, 'warning');

  ok.forEach(f => {
    if (!selectedFiles.find(sf => sf.name === f.name && sf.size === f.size))
      selectedFiles.push(f);
  });
  renderFileList();
  syncUploadBtn();
}

function removeFile(idx) {
  selectedFiles.splice(idx, 1);
  renderFileList();
  syncUploadBtn();
}

function clearFiles() {
  selectedFiles = [];
  renderFileList();
  syncUploadBtn();
  document.getElementById('uploadResults').style.display = 'none';
}

function syncUploadBtn() {
  const btn = document.getElementById('uploadBtn');
  btn.disabled = selectedFiles.length === 0;
  btn.innerHTML = selectedFiles.length
    ? `<i class="ri-rocket-2-line"></i> Parse & Analyze (${selectedFiles.length} file${selectedFiles.length > 1 ? 's' : ''})`
    : '<i class="ri-rocket-2-line"></i> Parse & Analyze';
}

function renderFileList() {
  const c = document.getElementById('fileList');
  if (!selectedFiles.length) { c.innerHTML = ''; return; }
  c.innerHTML = `<div style="display:flex;flex-direction:column;gap:6px;margin-top:4px">
    ${selectedFiles.map((f, i) => `
      <div style="display:flex;align-items:center;gap:10px;background:var(--bg-card);
                  border:1px solid var(--border);border-radius:8px;padding:10px 14px">
        <span style="font-size:20px;opacity:0.7">${fileIcon(f.name)}</span>
        <div style="flex:1;min-width:0">
          <div style="font-size:13px;font-weight:500;white-space:nowrap;
                      overflow:hidden;text-overflow:ellipsis">${esc(f.name)}</div>
          <div style="font-size:11px;color:var(--text-muted)">${fmtBytes(f.size)}</div>
        </div>
        <button onclick="removeFile(${i})"
          style="background:none;border:none;color:var(--text-muted);font-size:18px;
                 cursor:pointer;padding:2px 6px;border-radius:4px;flex-shrink:0"
          title="Remove"><i class="ri-close-line"></i></button>
      </div>`).join('')}
  </div>`;
}

function fileIcon(name) {
  if (/\.pdf$/i.test(name))  return '<i class="ri-file-pdf-2-line" style="color:#ef4444"></i>';
  if (/\.docx$/i.test(name)) return '<i class="ri-file-word-2-line" style="color:#3b82f6"></i>';
  return '<i class="ri-file-text-line" style="color:#a78bfa"></i>';
}

function fmtBytes(b) {
  if (b < 1024)       return b + ' B';
  if (b < 1024*1024)  return (b/1024).toFixed(1) + ' KB';
  return (b/1024/1024).toFixed(1) + ' MB';
}

// ── Upload handler ───────────────────────────────────────────────
async function handleUpload() {
  if (!selectedFiles.length) return;
  const jobId = document.getElementById('uploadJobSelect').value;

  showLoading('Uploading & parsing resumes with NLP…');
  let data;
  try {
    data = await apiUploadResumes(selectedFiles, jobId);
  } catch (e) {
    hideLoading();
    showToast('Upload failed — is the backend running?', 'error');
    console.error(e);
    return;
  }
  hideLoading();

  if (data.error) { showToast(data.error, 'error'); return; }

  const count = data.count || 0;
  showToast(`${count} resume${count !== 1 ? 's' : ''} parsed successfully!`, 'success');
  renderUploadResults(data.resumes || []);
  clearFiles();

  // Refresh global state
  try {
    const allData = await apiGetResumes();
    if (typeof allResumes !== 'undefined') {
      // eslint-disable-next-line no-undef
      allResumes = allData.resumes || [];
    }
  } catch(_) {}
  updateBadges();
  if (document.getElementById('page-dashboard').classList.contains('active')) {
    loadDashboard();
  }
}

// ── Results rendering ────────────────────────────────────────────
function renderUploadResults(resumes) {
  const section = document.getElementById('uploadResults');
  const list    = document.getElementById('uploadResultsList');
  const sub     = document.getElementById('uploadResultsSubtitle');

  section.style.display = 'block';
  if (sub) sub.textContent = `${resumes.length} resume${resumes.length !== 1 ? 's' : ''} parsed successfully`;

  if (!resumes.length) {
    list.innerHTML = '<p class="text-muted" style="text-align:center;padding:20px">No results to display.</p>';
    return;
  }

  list.innerHTML = resumes.map(r => {
    // If there was a parse error
    if (r.error) return `
      <div class="result-item" style="border-left:3px solid var(--danger)">
        <span style="font-size:24px;color:var(--warning)"><i class="ri-error-warning-line"></i></span>
        <div>
          <div style="font-weight:600;color:var(--danger)">${esc(r.filename)}</div>
          <div class="text-sm text-muted">${esc(r.error)}</div>
        </div>
      </div>`;

    const skillChips = (r.skills || []).slice(0, 8).map(s => {
      const cls = r.matched_skills?.includes(s) ? 'matched' : 'neutral';
      return `<span class="skill-chip ${cls}">${esc(s)}</span>`;
    }).join('');
    const extraSkills = (r.skills || []).length > 8
      ? `<span class="skill-chip neutral">+${r.skills.length - 8} more</span>` : '';

    const suggestions = r.improvement_suggestions || [];
    const suggHTML = suggestions.length ? `
      <details style="margin-top:10px">
        <summary style="font-size:12px;color:var(--accent);cursor:pointer;user-select:none">
          <i class="ri-lightbulb-line"></i> ${suggestions.length} improvement suggestion${suggestions.length > 1 ? 's' : ''}
        </summary>
        <ul class="suggestions-list" style="margin-top:8px">
          ${suggestions.map(s => `<li>${esc(s)}</li>`).join('')}
        </ul>
      </details>` : '';

    const missingHTML = r.missing_skills?.length ? `
      <div style="margin-top:8px">
        <span class="text-sm" style="color:var(--danger);font-weight:600">Missing skills: </span>
        ${r.missing_skills.slice(0, 5).map(s => `<span class="skill-chip missing">${esc(s)}</span>`).join(' ')}
      </div>` : '';

    return `
      <div class="result-item">
        <div style="font-size:28px;line-height:1">${fileIcon(r.filename)}</div>
        <div style="flex:1;min-width:0">
          <div style="font-size:15px;font-weight:700">${esc(r.candidate_name || 'Unknown Candidate')}</div>
          <div style="display:flex;gap:14px;margin:4px 0;font-size:12px;color:var(--text-muted);flex-wrap:wrap">
            ${r.email    ? `<span><i class="ri-mail-line"></i> ${esc(r.email)}</span>` : ''}
            ${r.phone    ? `<span><i class="ri-phone-line"></i> ${esc(r.phone)}</span>` : ''}
            ${r.experience_years ? `<span><i class="ri-briefcase-line"></i> ${r.experience_years} yrs exp</span>` : ''}
          </div>
          <div class="skill-chips" style="margin:6px 0">${skillChips}${extraSkills}</div>
          ${missingHTML}
          ${suggHTML}
        </div>
        <div style="text-align:center;flex-shrink:0;min-width:72px">
          ${scoreRing(r.matching_score)}
          <div class="star-rating" style="margin-top:5px;font-size:12px">${stars(r.matching_score)}</div>
          <div style="font-size:10px;color:var(--text-muted);margin-top:2px">Match Score</div>
        </div>
      </div>`;
  }).join('');
}

// ── Helpers (local copies to avoid cross-file dependency issues) ──
function esc(str) {
  return String(str ?? '')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#x27;');
}
function scoreRing(score) {
  const cls = score >= 70 ? 'score-high' : score >= 40 ? 'score-mid' : score > 0 ? 'score-low' : 'score-zero';
  return `<span class="score-badge ${cls}">${score}%</span>`;
}
function stars(score) {
  const n = Math.round((score / 100) * 5);
  return '★'.repeat(n) + '☆'.repeat(5 - n);
}
