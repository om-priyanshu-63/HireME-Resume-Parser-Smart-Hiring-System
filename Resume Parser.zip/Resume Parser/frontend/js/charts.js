/**
 * HireME — Charts Module (Chart.js 4)
 * Premium palette: Charcoal + Indigo
 */

const _charts = {};

// ── Theme colours ────────────────────────────────────────────────
const C = {
  indigo:     'rgba(99,102,241,0.75)',
  indigoSoft: 'rgba(99,102,241,0.5)',
  indigoBg:   'rgba(99,102,241,0.1)',
  emerald:    'rgba(52,211,153,0.75)',
  emeraldSoft:'rgba(52,211,153,0.2)',
  rose:       'rgba(248,113,113,0.75)',
  roseSoft:   'rgba(248,113,113,0.2)',
  amber:      'rgba(251,191,36,0.75)',
  slate:      'rgba(161,161,170,0.6)',
  slateMuted: 'rgba(113,113,122,0.5)',
  white10:    'rgba(255,255,255,0.1)',
  white06:    'rgba(255,255,255,0.06)',
  white04:    'rgba(255,255,255,0.04)',
  white02:    'rgba(255,255,255,0.02)',
  textFaint:  '#71717a',
  textMuted:  '#a1a1aa',
  textPrimary:'#fafafa',
  card:       '#18181b',
  surface:    '#0f0f12',
};

const DEFAULTS = {
  plugins: {
    legend: {
      labels: {
        color: C.textMuted,
        font: { family: 'Inter', size: 11, weight: 500 },
        padding: 14,
        usePointStyle: true,
        pointStyleWidth: 8,
      },
    },
    tooltip: {
      backgroundColor: C.card,
      borderColor: C.white10,
      borderWidth: 1,
      titleColor: C.textPrimary,
      bodyColor: C.textMuted,
      padding: 10,
      cornerRadius: 6,
      titleFont: { family: 'Inter', size: 12, weight: 600 },
      bodyFont:  { family: 'Inter', size: 11 },
    },
  },
  scales: {
    x: {
      ticks: { color: C.textFaint, font: { family: 'Inter', size: 10 } },
      grid:  { color: C.white04 },
      border:{ color: C.white06 },
    },
    y: {
      ticks: { color: C.textFaint, font: { family: 'Inter', size: 10 } },
      grid:  { color: C.white04 },
      border:{ color: C.white06 },
    },
  },
};

function mkChart(canvasId, config) {
  if (_charts[canvasId]) { _charts[canvasId].destroy(); delete _charts[canvasId]; }
  const canvas = document.getElementById(canvasId);
  if (!canvas) return null;
  _charts[canvasId] = new Chart(canvas.getContext('2d'), config);
  return _charts[canvasId];
}

// ── Status Doughnut ──────────────────────────────────────────────
function renderStatusChart(summary) {
  const p = summary.pending || 0, s = summary.shortlisted || 0, r = summary.rejected || 0;
  if (!p && !s && !r) {
    const cv = document.getElementById('statusChart');
    if (cv) { const ctx = cv.getContext('2d'); ctx.clearRect(0,0,cv.width,cv.height);
      ctx.fillStyle = C.textFaint; ctx.font = '12px Inter'; ctx.textAlign = 'center';
      ctx.fillText('No data yet', cv.width/2, cv.height/2); }
    return;
  }
  mkChart('statusChart', {
    type: 'doughnut',
    data: {
      labels: ['Pending', 'Shortlisted', 'Rejected'],
      datasets: [{
        data: [p, s, r],
        backgroundColor: [C.slateMuted, C.emerald, C.rose],
        borderColor: [C.surface, C.surface, C.surface],
        borderWidth: 2.5,
        hoverOffset: 6,
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      cutout: '68%',
      plugins: {
        ...DEFAULTS.plugins,
        legend: { ...DEFAULTS.plugins.legend, position: 'bottom' },
      },
    },
  });
}

// ── Score Distribution ───────────────────────────────────────────
function renderScoreDistChart(distribution) {
  const labels = Object.keys(distribution);
  const values = Object.values(distribution);

  mkChart('scoreDistChart', {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Candidates',
        data: values,
        backgroundColor: values.map((_, i) => {
          const pct = i / Math.max(labels.length - 1, 1);
          // Gradient from rose → amber → emerald
          if (pct < 0.4)      return C.rose;
          else if (pct < 0.7) return C.amber;
          else                return C.emerald;
        }),
        borderColor: 'transparent',
        borderWidth: 0,
        borderRadius: 4,
        barPercentage: 0.7,
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      plugins: { ...DEFAULTS.plugins, legend: { display: false } },
      scales: {
        ...DEFAULTS.scales,
        y: { ...DEFAULTS.scales.y, beginAtZero: true,
             ticks: { ...DEFAULTS.scales.y.ticks, stepSize: 1 } },
      },
    },
  });
}

// ── Skills Bar ───────────────────────────────────────────────────
function renderSkillsChart(skills, canvasId = 'skillsChart') {
  if (!skills.length) return;
  mkChart(canvasId, {
    type: 'bar',
    data: {
      labels: skills.map(s => s.skill),
      datasets: [{
        label: 'Occurrences',
        data: skills.map(s => s.count),
        backgroundColor: C.indigo,
        borderColor: 'transparent',
        borderWidth: 0,
        borderRadius: 3,
        hoverBackgroundColor: C.indigoSoft,
        barPercentage: 0.65,
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      indexAxis: canvasId === 'analyticsSkillsChart' ? 'x' : 'y',
      plugins: { ...DEFAULTS.plugins, legend: { display: false } },
      scales: {
        x: { ...DEFAULTS.scales.x, beginAtZero: true },
        y: { ...DEFAULTS.scales.y },
      },
    },
  });
}

// ── Funnel (HTML-based) ──────────────────────────────────────────
function renderFunnelChart(stages, containerId = 'funnelChart') {
  const el = document.getElementById(containerId);
  if (!el) return;
  if (!stages.length) {
    el.innerHTML = '<p style="color:#71717a;font-size:12px;text-align:center;padding:16px">No data</p>';
    return;
  }
  const max = Math.max(...stages.map(s => s.count), 1);
  const colors = [C.indigo, C.indigoSoft, C.emerald];
  el.innerHTML = stages.map((s, i) => {
    const pct = max > 0 ? Math.max((s.count / max) * 100, s.count > 0 ? 3 : 0) : 0;
    return `<div class="funnel-stage">
      <div class="funnel-label"><span>${s.stage}</span><strong>${s.count}</strong></div>
      <div class="progress-bar-wrap">
        <div class="progress-bar" style="width:${pct}%;background:${colors[i%3]};box-shadow:none"></div>
      </div>
    </div>`;
  }).join('');
}

// ── Job Score (Analytics) ────────────────────────────────────────
function renderJobScoreChart(jobs) {
  if (!jobs.length) {
    const cv = document.getElementById('jobScoreChart');
    if (cv) { const ctx = cv.getContext('2d'); ctx.clearRect(0,0,cv.width,cv.height);
      ctx.fillStyle = C.textFaint; ctx.font = '12px Inter'; ctx.textAlign = 'center';
      ctx.fillText('No job data', cv.width/2, cv.height/2); }
    return;
  }
  mkChart('jobScoreChart', {
    type: 'bar',
    data: {
      labels: jobs.map(j => j.title.length > 16 ? j.title.slice(0,15)+'…' : j.title),
      datasets: [
        {
          label: 'Avg Score (%)',
          data: jobs.map(j => j.avg_score),
          backgroundColor: C.indigo,
          borderColor: 'transparent', borderWidth: 0, borderRadius: 3,
          barPercentage: 0.55,
        },
        {
          label: 'Candidates',
          data: jobs.map(j => j.count),
          backgroundColor: C.emerald,
          borderColor: 'transparent', borderWidth: 0, borderRadius: 3,
          barPercentage: 0.55,
          yAxisID: 'y2',
        },
      ],
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      plugins: { ...DEFAULTS.plugins, legend: { ...DEFAULTS.plugins.legend, position: 'bottom' } },
      scales: {
        x: { ...DEFAULTS.scales.x },
        y: { ...DEFAULTS.scales.y, beginAtZero: true, max: 100,
             title: { display: true, text: 'Score %', color: C.textFaint, font: { size: 10 } } },
        y2: { ...DEFAULTS.scales.y, beginAtZero: true, position: 'right',
              grid: { display: false },
              title: { display: true, text: 'Count', color: C.textFaint, font: { size: 10 } } },
      },
    },
  });
}
