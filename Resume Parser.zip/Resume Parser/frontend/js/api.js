/**
 * HireME — API Layer
 * All backend communication; auto‑includes credentials (session cookies)
 */

const BASE = '';   // Same origin — Flask serves both API and frontend

async function apiFetch(path, opts = {}) {
  const res = await fetch(BASE + path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...opts.headers },
    ...opts,
  });
  if (!res.ok && res.status !== 400) {
    // 401 handled by callers; other errors thrown
    const body = await res.json().catch(() => ({ error: `HTTP ${res.status}` }));
    return body;
  }
  return res.json();
}

// ── Auth ─────────────────────────────────────────────────────────
function apiMe()               { return apiFetch('/api/auth/me'); }
function apiLogout()           { return apiFetch('/api/auth/logout', { method: 'POST' }); }
function apiLogin(username, password) {
  return apiFetch('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username, password }),
  });
}
function apiRegister(username, email, password) {
  return apiFetch('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ username, email, password }),
  });
}

// ── Jobs ─────────────────────────────────────────────────────────
function apiGetJobs()          { return apiFetch('/api/jobs/'); }
function apiGetJob(id)         { return apiFetch(`/api/jobs/${id}`); }
function apiCreateJob(payload) {
  return apiFetch('/api/jobs/', { method: 'POST', body: JSON.stringify(payload) });
}
function apiUpdateJob(id, payload) {
  return apiFetch(`/api/jobs/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
}
function apiDeleteJob(id) {
  return apiFetch(`/api/jobs/${id}`, { method: 'DELETE' });
}

// ── Resumes ──────────────────────────────────────────────────────
function apiGetResumes(params = {}) {
  const qs = new URLSearchParams(params).toString();
  return apiFetch(`/api/resumes/${qs ? '?' + qs : ''}`);
}
function apiGetResume(id) {
  return apiFetch(`/api/resumes/${id}`);
}
function apiUpdateStatus(id, status) {
  return apiFetch(`/api/resumes/${id}/status`, {
    method: 'PUT',
    body: JSON.stringify({ status }),
  });
}
function apiDeleteResume(id) {
  return apiFetch(`/api/resumes/${id}`, { method: 'DELETE' });
}

async function apiUploadResumes(files, jobId = '') {
  const form = new FormData();
  files.forEach(f => form.append('resumes', f));
  if (jobId) form.append('job_id', jobId);

  const res = await fetch('/api/resumes/upload', {
    method: 'POST',
    credentials: 'include',
    body: form,
    // No Content-Type header — browser sets multipart boundary automatically
  });
  return res.json();
}

// ── Export ───────────────────────────────────────────────────────
function exportResumes(format = 'csv', status = '', jobId = '') {
  const params = new URLSearchParams();
  if (status) params.set('status', status);
  if (jobId)  params.set('job_id', jobId);
  const qs = params.toString();
  window.open(`/api/resumes/export/${format}${qs ? '?' + qs : ''}`, '_blank');
}

// ── Analytics ────────────────────────────────────────────────────
function apiGetSummary()           { return apiFetch('/api/analytics/summary'); }
function apiGetScoreDistribution() { return apiFetch('/api/analytics/score-distribution'); }
function apiGetTopSkills()         { return apiFetch('/api/analytics/top-skills'); }
function apiGetHiringFunnel()      { return apiFetch('/api/analytics/hiring-funnel'); }
function apiGetScoreByJob()        { return apiFetch('/api/analytics/score-by-job'); }
