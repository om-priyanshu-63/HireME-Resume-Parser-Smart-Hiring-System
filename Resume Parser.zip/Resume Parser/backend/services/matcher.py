"""
Resume-to-Job Matching Service
Uses TF-IDF + Cosine Similarity for scoring.
"""
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import re


def preprocess_text(text):
    """Lowercase, remove non-alpha-numeric."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def compute_tfidf_similarity(resume_text, job_text):
    """Compute cosine similarity between resume and job description."""
    if not resume_text or not job_text:
        return 0.0
    r = preprocess_text(resume_text)
    j = preprocess_text(job_text)
    try:
        vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        tfidf_matrix = vectorizer.fit_transform([r, j])
        score = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
        return float(score)
    except Exception:
        return 0.0


def compute_skill_match(resume_skills, required_skills):
    """Percentage of required skills found in resume."""
    if not required_skills:
        return 1.0
    resume_lower = [s.lower() for s in resume_skills]
    required_lower = [s.lower() for s in required_skills]
    matched = sum(1 for s in required_lower if s in resume_lower)
    return matched / len(required_lower)


def compute_experience_score(resume_exp, min_exp):
    """Score based on experience meeting minimum requirement."""
    if min_exp <= 0:
        return 1.0
    if resume_exp >= min_exp:
        return 1.0
    return max(0.0, resume_exp / min_exp)


def calculate_matching_score(resume_data, job_data):
    """
    Weighted composite score:
    - TF-IDF text similarity: 40%
    - Skill match: 45%
    - Experience: 15%
    Returns score 0–100.
    """
    resume_text = resume_data.get("raw_text", "")
    job_text = (job_data.get("description", "") + " " +
                " ".join(job_data.get("required_skills", [])))

    tfidf_score = compute_tfidf_similarity(resume_text, job_text)
    skill_score = compute_skill_match(
        resume_data.get("skills", []),
        job_data.get("required_skills", [])
    )
    exp_score = compute_experience_score(
        resume_data.get("experience_years", 0),
        job_data.get("min_experience", 0)
    )

    # Weighted
    composite = (tfidf_score * 0.40) + (skill_score * 0.45) + (exp_score * 0.15)
    return round(composite * 100, 1)


def get_matched_skills(resume_skills, required_skills):
    """Return matched and missing skills."""
    resume_lower = {s.lower(): s for s in resume_skills}
    matched = []
    missing = []
    for skill in required_skills:
        if skill.lower() in resume_lower:
            matched.append(skill)
        else:
            missing.append(skill)
    return matched, missing


def rank_resumes(resumes_with_scores):
    """Sort resumes by matching_score descending."""
    return sorted(resumes_with_scores, key=lambda x: x.get("matching_score", 0), reverse=True)
