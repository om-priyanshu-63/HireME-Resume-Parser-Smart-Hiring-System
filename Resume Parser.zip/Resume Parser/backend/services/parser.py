"""
Resume Parser Service
Extracts text from PDF, DOCX, and TXT files.
Uses spaCy + regex for entity extraction.
"""
import re
import json
import os

# ----- Text Extraction -----

def extract_text_from_pdf(filepath):
    """Extract text from a PDF file using pdfplumber."""
    try:
        import pdfplumber
        text = ""
        with pdfplumber.open(filepath) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
        return text.strip()
    except Exception as e:
        # Fallback to PyMuPDF
        try:
            import fitz
            doc = fitz.open(filepath)
            text = ""
            for page in doc:
                text += page.get_text() + "\n"
            doc.close()
            return text.strip()
        except Exception as e2:
            return ""


def extract_text_from_docx(filepath):
    """Extract text from a DOCX file."""
    try:
        from docx import Document
        doc = Document(filepath)
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        # Also extract from tables
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    if cell.text.strip():
                        paragraphs.append(cell.text.strip())
        return "\n".join(paragraphs)
    except Exception as e:
        return ""


def extract_text_from_txt(filepath):
    """Read plain text file."""
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception:
        return ""


def extract_text(filepath, file_ext):
    """Route to the correct extractor based on file extension."""
    ext = file_ext.lower().strip(".")
    if ext == "pdf":
        return extract_text_from_pdf(filepath)
    elif ext == "docx":
        return extract_text_from_docx(filepath)
    elif ext == "txt":
        return extract_text_from_txt(filepath)
    return ""


# ----- Entity Extraction -----

EMAIL_PATTERN = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")
PHONE_PATTERN = re.compile(
    r"(?:\+?\d{1,3}[\s\-]?)?"
    r"(?:\(?\d{2,4}\)?[\s\-]?)?"
    r"\d{3,4}[\s\-]?\d{4}"
)

SKILLS_DB = [
    # Programming Languages
    "python", "java", "javascript", "typescript", "c++", "c#", "c", "ruby", "go",
    "golang", "rust", "swift", "kotlin", "php", "r", "matlab", "scala", "perl",
    # Web
    "html", "css", "react", "angular", "vue", "node.js", "nodejs", "express",
    "django", "flask", "fastapi", "spring", "asp.net", "laravel", "jquery",
    "bootstrap", "tailwind", "graphql", "rest api", "restful",
    # Data / ML / AI
    "machine learning", "deep learning", "nlp", "natural language processing",
    "computer vision", "tensorflow", "pytorch", "keras", "scikit-learn", "sklearn",
    "pandas", "numpy", "matplotlib", "seaborn", "opencv", "hugging face",
    "transformers", "bert", "gpt", "llm", "langchain", "data analysis",
    "data science", "data engineering", "feature engineering", "model deployment",
    # Databases
    "sql", "mysql", "postgresql", "mongodb", "redis", "sqlite", "oracle",
    "cassandra", "dynamodb", "firebase", "elasticsearch",
    # Cloud / DevOps
    "aws", "azure", "gcp", "google cloud", "docker", "kubernetes", "k8s",
    "jenkins", "github actions", "ci/cd", "terraform", "ansible", "linux",
    "bash", "shell scripting",
    # Tools
    "git", "github", "gitlab", "jira", "confluence", "figma", "postman",
    "jupyter", "vscode", "intellij", "excel", "power bi", "tableau",
    # Soft Skills / Other
    "agile", "scrum", "kanban", "communication", "leadership", "problem solving",
    "teamwork", "project management",
]

EDUCATION_KEYWORDS = [
    "b.tech", "btech", "b.e", "be", "b.sc", "bsc", "b.com", "bcom",
    "m.tech", "mtech", "m.e", "me", "m.sc", "msc", "mba", "phd", "ph.d",
    "bachelor", "master", "doctorate", "diploma", "degree",
    "university", "college", "institute", "iit", "nit", "bits",
    "computer science", "information technology", "engineering", "electronics",
]

EXPERIENCE_PATTERNS = [
    re.compile(r"(\d+\.?\d*)\s*\+?\s*(?:years?|yrs?)\s*(?:of\s*)?(?:experience|exp)", re.IGNORECASE),
    re.compile(r"experience[:\s]+(\d+\.?\d*)\s*\+?\s*(?:years?|yrs?)", re.IGNORECASE),
]

SECTION_HEADERS = {
    "experience": ["experience", "work experience", "professional experience", "employment", "career"],
    "education": ["education", "academic", "qualification", "degree"],
    "skills": ["skills", "technical skills", "core competencies", "technologies", "expertise"],
    "projects": ["projects", "personal projects", "academic projects"],
    "certifications": ["certifications", "certificates", "courses"],
    "achievements": ["achievements", "awards", "accomplishments"],
}


def extract_name(text):
    """Try to extract candidate name from the first few lines."""
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    # Try spaCy NER first
    try:
        import spacy
        nlp = spacy.load("en_core_web_sm")
        doc = nlp("\n".join(lines[:10]))
        for ent in doc.ents:
            if ent.label_ == "PERSON" and len(ent.text.split()) >= 2:
                return ent.text.strip()
    except Exception:
        pass
    # Fallback: first non-email, non-phone line with 2-4 words and title case
    for line in lines[:8]:
        line = line.strip()
        if EMAIL_PATTERN.search(line) or PHONE_PATTERN.search(line):
            continue
        words = line.split()
        if 2 <= len(words) <= 4 and all(w[0].isupper() for w in words if w.isalpha()):
            # Check it's not an address/section header
            if not any(kw in line.lower() for kw in ["resume", "curriculum", "vitae", "cv", "profile"]):
                return line
    return None


def extract_email(text):
    matches = EMAIL_PATTERN.findall(text)
    return matches[0] if matches else None


def extract_phone(text):
    matches = PHONE_PATTERN.findall(text)
    # Clean and return first plausible phone
    for m in matches:
        cleaned = re.sub(r"[\s\-\(\)]", "", m)
        if len(cleaned) >= 10:
            return m.strip()
    return None


def extract_skills(text):
    """Match skills from SKILLS_DB against resume text (case-insensitive)."""
    text_lower = text.lower()
    found = []
    for skill in SKILLS_DB:
        # Use word boundary matching
        pattern = r"\b" + re.escape(skill) + r"\b"
        if re.search(pattern, text_lower):
            found.append(skill)
    return list(dict.fromkeys(found))  # deduplicate preserving order


def extract_education(text):
    """Extract education entries from the education section."""
    lines = text.split("\n")
    in_section = False
    edu_lines = []
    
    for line in lines:
        line_lower = line.lower().strip()
        if any(kw in line_lower for kw in SECTION_HEADERS["education"]):
            in_section = True
            continue
        if in_section:
            # Stop at next major section
            if any(
                any(kw in line_lower for kw in v)
                for k, v in SECTION_HEADERS.items() if k != "education"
            ) and len(line.strip()) < 50:
                in_section = False
            elif line.strip():
                edu_lines.append(line.strip())

    # If section not found, scan globally
    if not edu_lines:
        for line in lines:
            ll = line.lower()
            if any(kw in ll for kw in EDUCATION_KEYWORDS):
                edu_lines.append(line.strip())

    return edu_lines[:6]  # max 6 entries


def extract_experience_years(text):
    """Extract years of experience from text."""
    for pattern in EXPERIENCE_PATTERNS:
        match = pattern.search(text)
        if match:
            return float(match.group(1))
    return 0.0


def extract_experience_details(text):
    """Extract job titles / company names from experience section."""
    lines = text.split("\n")
    in_section = False
    exp_lines = []

    for line in lines:
        line_lower = line.lower().strip()
        if any(kw in line_lower for kw in SECTION_HEADERS["experience"]):
            in_section = True
            continue
        if in_section:
            if any(
                any(kw in line_lower for kw in v)
                for k, v in SECTION_HEADERS.items() if k != "experience"
            ) and len(line.strip()) < 50:
                in_section = False
            elif line.strip():
                exp_lines.append(line.strip())

    return exp_lines[:10]


def detect_sections(text):
    """Detect which sections are present in the resume."""
    text_lower = text.lower()
    present = {}
    for section, keywords in SECTION_HEADERS.items():
        present[section] = any(kw in text_lower for kw in keywords)
    return present


def generate_improvement_suggestions(skills, education, experience_details, sections, required_skills=None):
    """Generate improvement suggestions based on resume content."""
    suggestions = []

    # Missing sections
    if not sections.get("projects"):
        suggestions.append("➕ Add a Projects section to showcase hands-on experience.")
    if not sections.get("certifications"):
        suggestions.append("🏆 Include relevant Certifications or Online Courses.")
    if not sections.get("achievements"):
        suggestions.append("⭐ Add an Achievements/Awards section to stand out.")

    # Skills gap
    if required_skills:
        missing = [s for s in required_skills if s.lower() not in [sk.lower() for sk in skills]]
        if missing:
            suggestions.append(f"🔑 Consider adding these in-demand skills: {', '.join(missing[:5])}.")

    # General
    if len(skills) < 5:
        suggestions.append("🛠️ Expand your Skills section with more technical and soft skills.")
    if not education:
        suggestions.append("🎓 Add your Educational background for a complete profile.")
    if not experience_details:
        suggestions.append("💼 Add detailed Work Experience with company names and responsibilities.")

    # Keywords
    suggestions.append("🔍 Use action verbs (Led, Developed, Implemented) to strengthen bullet points.")
    suggestions.append("📊 Quantify achievements (e.g., 'Improved performance by 30%').")

    return suggestions[:7]


def parse_resume(filepath, file_ext, required_skills=None):
    """
    Main parsing function.
    Returns a dict with all extracted fields.
    """
    text = extract_text(filepath, file_ext)
    if not text:
        return {
            "error": "Could not extract text from file.",
            "raw_text": "",
            "candidate_name": None,
            "email": None,
            "phone": None,
            "skills": [],
            "education": [],
            "experience_years": 0,
            "experience_details": [],
            "improvement_suggestions": [],
        }

    skills = extract_skills(text)
    education = extract_education(text)
    experience_years = extract_experience_years(text)
    experience_details = extract_experience_details(text)
    sections = detect_sections(text)
    suggestions = generate_improvement_suggestions(
        skills, education, experience_details, sections, required_skills
    )

    return {
        "raw_text": text,
        "candidate_name": extract_name(text),
        "email": extract_email(text),
        "phone": extract_phone(text),
        "skills": skills,
        "education": education,
        "experience_years": experience_years,
        "experience_details": experience_details,
        "improvement_suggestions": suggestions,
    }
