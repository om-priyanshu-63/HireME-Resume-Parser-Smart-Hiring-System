"""
Export Service — CSV and Excel generation for shortlisted/all resumes.
"""
import io
import csv
import json


def generate_csv(resumes):
    """Generate CSV bytes from a list of resume dicts."""
    output = io.StringIO()
    fields = [
        "id", "candidate_name", "email", "phone",
        "skills", "education", "experience_years",
        "matching_score", "status", "uploaded_at"
    ]
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for r in resumes:
        row = dict(r)
        # Flatten lists to semicolon-separated strings
        if isinstance(row.get("skills"), list):
            row["skills"] = "; ".join(row["skills"])
        if isinstance(row.get("education"), list):
            row["education"] = "; ".join(row["education"])
        writer.writerow(row)
    return output.getvalue().encode("utf-8")


def generate_excel(resumes):
    """Generate Excel bytes from a list of resume dicts."""
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Candidates"

        headers = [
            "ID", "Name", "Email", "Phone",
            "Skills", "Education", "Experience (yrs)",
            "Match Score (%)", "Status", "Uploaded At"
        ]
        # Style header
        header_fill = PatternFill("solid", fgColor="1A3A5C")
        header_font = Font(color="FFFFFF", bold=True)
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center")
            ws.column_dimensions[cell.column_letter].width = max(15, len(header) + 5)

        # Data rows
        for row_num, r in enumerate(resumes, 2):
            skills_str = "; ".join(r.get("skills", [])) if isinstance(r.get("skills"), list) else ""
            edu_str = "; ".join(r.get("education", [])) if isinstance(r.get("education"), list) else ""
            ws.append([
                r.get("id"),
                r.get("candidate_name"),
                r.get("email"),
                r.get("phone"),
                skills_str,
                edu_str,
                r.get("experience_years"),
                r.get("matching_score"),
                r.get("status"),
                r.get("uploaded_at"),
            ])
            # Alternating row colors
            fill_color = "EAF0FB" if row_num % 2 == 0 else "FFFFFF"
            fill = PatternFill("solid", fgColor=fill_color)
            for col in range(1, len(headers) + 1):
                ws.cell(row=row_num, column=col).fill = fill

        bytes_io = io.BytesIO()
        wb.save(bytes_io)
        bytes_io.seek(0)
        return bytes_io.read()
    except ImportError:
        # Fall back to CSV if openpyxl unavailable
        return generate_csv(resumes)
