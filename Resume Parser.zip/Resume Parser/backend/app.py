"""
Flask Application Entry Point — Resume Parser & Smart Hiring System
MongoDB Backend
"""
import os
import sys
import mimetypes

# Force UTF-8 output on Windows
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

# Fix MIME types on Windows (Windows registry can override these incorrectly)
mimetypes.add_type("text/css", ".css")
mimetypes.add_type("application/javascript", ".js")
mimetypes.add_type("text/html", ".html")
mimetypes.add_type("application/json", ".json")
mimetypes.add_type("image/svg+xml", ".svg")
mimetypes.add_type("image/png", ".png")
mimetypes.add_type("image/jpeg", ".jpg")
mimetypes.add_type("image/jpeg", ".jpeg")
mimetypes.add_type("font/woff2", ".woff2")
mimetypes.add_type("font/woff", ".woff")

from flask import Flask, jsonify, send_from_directory, request
from flask_cors import CORS
from flask_login import LoginManager
from models.database import mongo, User
from routes.auth import auth_bp
from routes.resume import resume_bp
from routes.jobs import jobs_bp
from routes.analytics import analytics_bp
from config import Config


def create_app():
    # Resolve frontend folder as an absolute path to avoid path issues
    frontend_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend"))

    app = Flask(__name__, static_folder=frontend_dir, static_url_path="")
    app.config.from_object(Config)

    # Extensions
    CORS(app, supports_credentials=True, origins=["http://localhost:5000",
                                                   "http://127.0.0.1:5000"])

    # Initialize MongoDB
    mongo.init_app(app)

    login_manager = LoginManager(app)

    @login_manager.user_loader
    def load_user(user_id):
        return User.find_by_id(int(user_id))

    @login_manager.unauthorized_handler
    def unauthorized():
        # If it's an API request return JSON, otherwise redirect to login
        if request.path.startswith("/api/"):
            return jsonify({"error": "Authentication required.", "code": 401}), 401
        return send_from_directory(app.static_folder, "login.html")

    # Register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(resume_bp)
    app.register_blueprint(jobs_bp)
    app.register_blueprint(analytics_bp)

    # Demo data seeding route
    @app.route("/api/seed-demo", methods=["POST"])
    def seed_demo():
        """Seed the database with demo job + sample candidates for demo purposes."""
        from models.database import JobDescription, Resume
        import json

        # Only seed if < 3 resumes exist
        if Resume.count() >= 3:
            return jsonify({"message": "Demo data already seeded."})

        # Create a sample job
        job = JobDescription.find_by_title("Senior Python Developer")
        if not job:
            job = JobDescription.create(
                title="Senior Python Developer",
                description="We need an experienced Python developer with strong backend skills, "
                            "knowledge of REST APIs, databases, and cloud platforms.",
                required_skills=["python", "flask", "django", "sql", "docker", "aws", "git", "rest api"],
                min_experience=3,
                created_by=1,
            )

        # Sample candidates
        candidates = [
            {"name": "Arjun Sharma", "email": "arjun.sharma@email.com", "phone": "+91 9876543210",
             "skills": ["python", "django", "sql", "docker", "git", "aws", "rest api", "linux"],
             "education": ["B.Tech Computer Science, IIT Delhi, 2018"],
             "exp_years": 5, "score": 87.4, "status": "shortlisted"},
            {"name": "Priya Nair", "email": "priya.nair@email.com", "phone": "+91 8765432109",
             "skills": ["python", "flask", "mongodb", "react", "git", "postgresql"],
             "education": ["M.Tech Information Technology, NIT Trichy, 2020"],
             "exp_years": 4, "score": 72.1, "status": "shortlisted"},
            {"name": "Rahul Gupta", "email": "rahul.gupta@email.com", "phone": "+91 9988776655",
             "skills": ["java", "spring", "mysql", "git", "docker"],
             "education": ["B.Tech Electronics, VIT, 2019"],
             "exp_years": 3, "score": 38.5, "status": "rejected"},
            {"name": "Sneha Patel", "email": "sneha.patel@email.com", "phone": "+91 7654321098",
             "skills": ["python", "machine learning", "pandas", "numpy", "scikit-learn", "sql", "git"],
             "education": ["M.Sc Data Science, BITS Pilani, 2021"],
             "exp_years": 2, "score": 65.3, "status": "pending"},
            {"name": "Karthik Reddy", "email": "karthik.reddy@email.com", "phone": "+91 8543219876",
             "skills": ["python", "aws", "docker", "kubernetes", "terraform", "bash", "git", "ci/cd"],
             "education": ["B.E Computer Science, Anna University, 2017"],
             "exp_years": 6, "score": 81.2, "status": "shortlisted"},
            {"name": "Meena Iyer", "email": "meena.iyer@email.com", "phone": "+91 9123456780",
             "skills": ["javascript", "react", "node.js", "mongodb", "git"],
             "education": ["B.Tech IT, Mumbai University, 2020"],
             "exp_years": 3, "score": 29.8, "status": "rejected"},
            {"name": "Vikram Singh", "email": "vikram.singh@email.com", "phone": "+91 8901234567",
             "skills": ["python", "flask", "sql", "redis", "docker", "aws", "git", "rest api", "linux"],
             "education": ["B.Tech CSE, DTU Delhi, 2016"],
             "exp_years": 7, "score": 91.0, "status": "shortlisted"},
            {"name": "Ananya Das", "email": "ananya.das@email.com", "phone": "+91 7890123456",
             "skills": ["python", "data science", "tensorflow", "pandas", "sql"],
             "education": ["M.Tech AI, IIT Bombay, 2022"],
             "exp_years": 1, "score": 56.7, "status": "pending"},
        ]

        for c in candidates:
            Resume.create(
                filename=f"demo_{c['name'].replace(' ', '_').lower()}.pdf",
                original_filename=f"{c['name'].replace(' ', '_')}_Resume.pdf",
                file_type="pdf",
                candidate_name=c["name"],
                email=c["email"],
                phone=c["phone"],
                raw_text=f"Resume of {c['name']}. Skills: {', '.join(c['skills'])}. Education: {'; '.join(c['education'])}.",
                experience_years=c["exp_years"],
                matching_score=c["score"],
                status=c["status"],
                job_id=job.id,
                uploaded_by=1,
                skills=c["skills"],
                education=c["education"],
                experience_details=[f"Software Engineer at Tech Corp ({c['exp_years']} years)"],
                improvement_suggestions=[
                    "Add quantified achievements to stand out.",
                    "Include links to GitHub/Portfolio.",
                    "Add a Projects section with details.",
                ],
            )

        return jsonify({"message": "Demo data seeded successfully!", "job_id": job.id})

    # ── Serve frontend pages ─────────────────────────────────────
    @app.route("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    @app.route("/login")
    def login_page():
        return send_from_directory(app.static_folder, "login.html")

    # Serve static assets (CSS, JS, images) with correct MIME types
    @app.route("/css/<path:filename>")
    def serve_css(filename):
        return send_from_directory(
            os.path.join(app.static_folder, "css"), filename,
            mimetype="text/css"
        )

    @app.route("/js/<path:filename>")
    def serve_js(filename):
        return send_from_directory(
            os.path.join(app.static_folder, "js"), filename,
            mimetype="application/javascript"
        )

    # Catch-all for any other static files
    @app.route("/<path:path>")
    def serve_static(path):
        full = os.path.join(app.static_folder, path)
        if os.path.exists(full) and os.path.isfile(full):
            # Determine MIME type
            mime, _ = mimetypes.guess_type(full)
            if mime:
                return send_from_directory(app.static_folder, path, mimetype=mime)
            return send_from_directory(app.static_folder, path)
        return send_from_directory(app.static_folder, "index.html")

    # Seed default admin user
    _seed_default_user()

    return app


def _seed_default_user():
    from werkzeug.security import generate_password_hash
    if User.count() == 0:
        User.create(
            username="admin",
            email="admin@hireme.com",
            password_hash=generate_password_hash("admin123"),
            role="admin",
        )
        print("[OK] Default admin created: admin / admin123")


app = create_app()

if __name__ == "__main__":
    print("[*] HireME - Resume Parser & Smart Hiring System")
    print("    Backend : MongoDB")
    print("    URL     : http://localhost:5000")
    print("    Login   : admin / admin123")
    app.run(debug=True, host="0.0.0.0", port=5000, use_reloader=False)
