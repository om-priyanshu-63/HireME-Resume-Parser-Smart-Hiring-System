"""
Resume routes — Upload, parse, match, status update, export (MongoDB version).
"""
import os
import json
import uuid
from flask import Blueprint, request, jsonify, send_file, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from models.database import Resume, JobDescription
from services.parser import parse_resume
from services.matcher import calculate_matching_score, get_matched_skills
from services.exporter import generate_csv, generate_excel
import io

resume_bp = Blueprint("resume", __name__, url_prefix="/api/resumes")

ALLOWED_EXTENSIONS = {"pdf", "docx", "txt"}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@resume_bp.route("/upload", methods=["POST"])
@login_required
def upload_resume():
    """Upload one or more resumes, parse and optionally match against a job."""
    if "resumes" not in request.files:
        return jsonify({"error": "No files uploaded."}), 400

    files = request.files.getlist("resumes")
    job_id = request.form.get("job_id")
    job = None
    job_data = {}

    if job_id:
        job = JobDescription.find_by_id(int(job_id))
        if job:
            job_data = {
                "description": job.description,
                "required_skills": job.get_skills(),
                "min_experience": job.min_experience,
            }

    results = []
    upload_folder = current_app.config["UPLOAD_FOLDER"]

    for file in files:
        if not file or not file.filename:
            continue
        if not allowed_file(file.filename):
            results.append({"filename": file.filename, "error": "Unsupported file type."})
            continue

        original_name = secure_filename(file.filename)
        ext = original_name.rsplit(".", 1)[1].lower()
        unique_name = f"{uuid.uuid4().hex}_{original_name}"
        filepath = os.path.join(upload_folder, unique_name)
        file.save(filepath)

        # Parse
        parsed = parse_resume(filepath, ext, required_skills=job_data.get("required_skills"))

        # Calculate match score
        score = 0.0
        if job_data:
            score = calculate_matching_score(parsed, job_data)

        # Save to MongoDB
        r = Resume.create(
            filename=unique_name,
            original_filename=original_name,
            file_type=ext,
            candidate_name=parsed.get("candidate_name"),
            email=parsed.get("email"),
            phone=parsed.get("phone"),
            raw_text=(parsed.get("raw_text", "") or "")[:50000],
            experience_years=parsed.get("experience_years", 0),
            matching_score=score,
            skills=parsed.get("skills", []),
            education=parsed.get("education", []),
            experience_details=parsed.get("experience_details", []),
            improvement_suggestions=parsed.get("improvement_suggestions", []),
            job_id=job.id if job else None,
            uploaded_by=current_user.id,
            status="pending",
        )

        result_dict = r.to_dict()
        if job:
            matched, missing = get_matched_skills(parsed.get("skills", []), job.get_skills())
            result_dict["matched_skills"] = matched
            result_dict["missing_skills"] = missing
        results.append(result_dict)

    return jsonify({"resumes": results, "count": len(results)}), 201


@resume_bp.route("/", methods=["GET"])
@login_required
def list_resumes():
    """List resumes with optional filters."""
    job_id = request.args.get("job_id")
    status = request.args.get("status")
    search = request.args.get("search", "")

    filters = {}
    if job_id:
        filters["job_id"] = int(job_id)
    if status:
        filters["status"] = status
    if search:
        # Case-insensitive search on candidate_name or email
        import re as _re
        search_regex = _re.compile(_re.escape(search), _re.IGNORECASE)
        filters["$or"] = [
            {"candidate_name": {"$regex": search_regex}},
            {"email": {"$regex": search_regex}},
        ]

    resumes = Resume.find_all(filters=filters, sort_field="matching_score", sort_dir=-1)
    return jsonify({"resumes": [r.to_dict() for r in resumes]})


@resume_bp.route("/<int:resume_id>", methods=["GET"])
@login_required
def get_resume(resume_id):
    r = Resume.find_by_id(resume_id)
    if not r:
        return jsonify({"error": "Resume not found."}), 404
    data = r.to_dict()
    # Include matched/missing skills if job is linked
    if r.job_id:
        job = JobDescription.find_by_id(r.job_id)
        if job:
            matched, missing = get_matched_skills(r.get_skills(), job.get_skills())
            data["matched_skills"] = matched
            data["missing_skills"] = missing
            data["job"] = job.to_dict()
    return jsonify({"resume": data})


@resume_bp.route("/<int:resume_id>/status", methods=["PUT"])
@login_required
def update_status(resume_id):
    """Shortlist or reject a resume."""
    r = Resume.find_by_id(resume_id)
    if not r:
        return jsonify({"error": "Resume not found."}), 404
    data = request.get_json()
    new_status = data.get("status")
    if new_status not in ("pending", "shortlisted", "rejected"):
        return jsonify({"error": "Invalid status."}), 400
    Resume.update(resume_id, {"status": new_status})
    r = Resume.find_by_id(resume_id)
    return jsonify({"message": "Status updated.", "resume": r.to_dict()})


@resume_bp.route("/<int:resume_id>", methods=["DELETE"])
@login_required
def delete_resume(resume_id):
    r = Resume.find_by_id(resume_id)
    if not r:
        return jsonify({"error": "Resume not found."}), 404
    # Remove file
    try:
        filepath = os.path.join(current_app.config["UPLOAD_FOLDER"], r.filename)
        if os.path.exists(filepath):
            os.remove(filepath)
    except Exception:
        pass
    Resume.delete(resume_id)
    return jsonify({"message": "Resume deleted."})


@resume_bp.route("/export/csv", methods=["GET"])
@login_required
def export_csv():
    job_id = request.args.get("job_id")
    status = request.args.get("status")
    filters = {}
    if job_id:
        filters["job_id"] = int(job_id)
    if status:
        filters["status"] = status
    resumes = [r.to_dict() for r in Resume.find_all(filters=filters)]
    csv_data = generate_csv(resumes)
    return send_file(
        io.BytesIO(csv_data),
        mimetype="text/csv",
        as_attachment=True,
        download_name="candidates.csv",
    )


@resume_bp.route("/export/excel", methods=["GET"])
@login_required
def export_excel():
    job_id = request.args.get("job_id")
    status = request.args.get("status")
    filters = {}
    if job_id:
        filters["job_id"] = int(job_id)
    if status:
        filters["status"] = status
    resumes = [r.to_dict() for r in Resume.find_all(filters=filters)]
    excel_data = generate_excel(resumes)
    return send_file(
        io.BytesIO(excel_data),
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="candidates.xlsx",
    )
