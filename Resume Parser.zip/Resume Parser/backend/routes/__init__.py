# routes/__init__.py
from .auth import auth_bp
from .resume import resume_bp
from .jobs import jobs_bp
from .analytics import analytics_bp
