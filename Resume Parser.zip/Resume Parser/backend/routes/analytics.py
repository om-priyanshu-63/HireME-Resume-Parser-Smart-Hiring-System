"""Analytics routes — Dashboard stats and chart data (MongoDB version)."""
from flask import Blueprint, jsonify, request
from flask_login import login_required
from models.database import mongo, Resume, JobDescription
from collections import Counter

analytics_bp = Blueprint("analytics", __name__, url_prefix="/api/analytics")


@analytics_bp.route("/summary", methods=["GET"])
@login_required
def summary():
    """Overall hiring funnel metrics."""
    total = Resume.count()
    shortlisted = Resume.count({"status": "shortlisted"})
    rejected = Resume.count({"status": "rejected"})
    pending = Resume.count({"status": "pending"})
    total_jobs = JobDescription.count()

    # Average matching score via aggregation
    pipeline = [{"$group": {"_id": None, "avg_score": {"$avg": "$matching_score"}}}]
    agg = Resume.aggregate(pipeline)
    avg_score = agg[0]["avg_score"] if agg else 0

    return jsonify({
        "total_resumes": total,
        "shortlisted": shortlisted,
        "rejected": rejected,
        "pending": pending,
        "avg_matching_score": round(float(avg_score or 0), 1),
        "total_jobs": total_jobs,
    })


@analytics_bp.route("/score-distribution", methods=["GET"])
@login_required
def score_distribution():
    """Histogram data: count of resumes per score bucket (0-10, 10-20, ... 90-100)."""
    job_id = request.args.get("job_id")
    filters = {}
    if job_id:
        filters["job_id"] = int(job_id)
    resumes = Resume.find_all(filters=filters)

    buckets = {f"{i*10}-{i*10+10}": 0 for i in range(10)}
    for r in resumes:
        bucket_idx = min(int(r.matching_score // 10), 9)
        key = f"{bucket_idx*10}-{bucket_idx*10+10}"
        buckets[key] += 1

    return jsonify({"distribution": buckets})


@analytics_bp.route("/top-skills", methods=["GET"])
@login_required
def top_skills():
    """Frequency of skills across all resumes."""
    job_id = request.args.get("job_id")
    filters = {}
    if job_id:
        filters["job_id"] = int(job_id)
    resumes = Resume.find_all(filters=filters)

    counter = Counter()
    for r in resumes:
        for skill in r.get_skills():
            counter[skill] += 1

    top = counter.most_common(15)
    return jsonify({"skills": [{"skill": s, "count": c} for s, c in top]})


@analytics_bp.route("/hiring-funnel", methods=["GET"])
@login_required
def hiring_funnel():
    """Funnel stages for visualization."""
    job_id = request.args.get("job_id")
    filters = {}
    if job_id:
        filters["job_id"] = int(job_id)

    total = Resume.count(filters)
    scored_filters = {**filters, "matching_score": {"$gt": 0}}
    scored = Resume.count(scored_filters)
    shortlisted_filters = {**filters, "status": "shortlisted"}
    shortlisted = Resume.count(shortlisted_filters)

    return jsonify({
        "stages": [
            {"stage": "Uploaded", "count": total},
            {"stage": "Parsed & Scored", "count": scored},
            {"stage": "Shortlisted", "count": shortlisted},
        ]
    })


@analytics_bp.route("/score-by-job", methods=["GET"])
@login_required
def score_by_job():
    """Average score per job using MongoDB aggregation."""
    pipeline = [
        {"$match": {"job_id": {"$ne": None}}},
        {
            "$group": {
                "_id": "$job_id",
                "avg_score": {"$avg": "$matching_score"},
                "count": {"$sum": 1},
            }
        },
    ]
    agg_results = Resume.aggregate(pipeline)

    jobs_data = []
    for entry in agg_results:
        job = JobDescription.find_by_id(entry["_id"])
        if job:
            jobs_data.append({
                "title": job.title,
                "avg_score": round(float(entry["avg_score"]), 1),
                "count": entry["count"],
            })

    return jsonify({"jobs": jobs_data})
