"""Job description routes — CRUD for job postings (MongoDB version)."""
from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from models.database import JobDescription

jobs_bp = Blueprint("jobs", __name__, url_prefix="/api/jobs")


@jobs_bp.route("/", methods=["GET"])
@login_required
def list_jobs():
    jobs = JobDescription.find_all(sort_field="created_at", sort_dir=-1)
    return jsonify({"jobs": [j.to_dict() for j in jobs]})


@jobs_bp.route("/", methods=["POST"])
@login_required
def create_job():
    data = request.get_json()
    title = data.get("title", "").strip()
    description = data.get("description", "").strip()
    required_skills = data.get("required_skills", [])
    min_experience = float(data.get("min_experience", 0))

    if not title or not description:
        return jsonify({"error": "Title and description required."}), 400

    job = JobDescription.create(
        title=title,
        description=description,
        required_skills=required_skills,
        min_experience=min_experience,
        created_by=current_user.id,
    )
    return jsonify({"message": "Job created.", "job": job.to_dict()}), 201


@jobs_bp.route("/<int:job_id>", methods=["GET"])
@login_required
def get_job(job_id):
    job = JobDescription.find_by_id(job_id)
    if not job:
        return jsonify({"error": "Job not found."}), 404
    return jsonify({"job": job.to_dict()})


@jobs_bp.route("/<int:job_id>", methods=["PUT"])
@login_required
def update_job(job_id):
    job = JobDescription.find_by_id(job_id)
    if not job:
        return jsonify({"error": "Job not found."}), 404

    data = request.get_json()
    update_fields = {}
    if "title" in data:
        update_fields["title"] = data["title"]
    if "description" in data:
        update_fields["description"] = data["description"]
    if "required_skills" in data:
        update_fields["required_skills"] = data["required_skills"]
    if "min_experience" in data:
        update_fields["min_experience"] = float(data["min_experience"])

    if update_fields:
        JobDescription.update(job_id, update_fields)

    # Re-fetch for updated response
    job = JobDescription.find_by_id(job_id)
    return jsonify({"message": "Job updated.", "job": job.to_dict()})


@jobs_bp.route("/<int:job_id>", methods=["DELETE"])
@login_required
def delete_job(job_id):
    job = JobDescription.find_by_id(job_id)
    if not job:
        return jsonify({"error": "Job not found."}), 404
    JobDescription.delete(job_id)
    return jsonify({"message": "Job deleted."})
