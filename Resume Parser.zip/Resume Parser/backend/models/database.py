"""
MongoDB Data Access Layer — Resume Parser & Smart Hiring System
Replaces SQLAlchemy ORM with PyMongo for MongoDB.
"""
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime
from flask_login import UserMixin


class MongoManager:
    """Singleton that holds the PyMongo client and database reference."""

    def __init__(self):
        self.client = None
        self.db = None

    def init_app(self, app):
        """Initialize MongoDB connection from Flask app config."""
        uri = app.config.get("MONGO_URI", "mongodb://localhost:27017/")
        db_name = app.config.get("MONGO_DB_NAME", "hireme_db")
        self.client = MongoClient(uri)
        self.db = self.client[db_name]

        # Create indexes for performance
        self._ensure_indexes()

    def _ensure_indexes(self):
        """Create useful indexes on collections."""
        self.db.users.create_index("username", unique=True)
        self.db.users.create_index("email", unique=True)
        self.db.jobs.create_index("created_at")
        self.db.resumes.create_index("job_id")
        self.db.resumes.create_index("status")
        self.db.resumes.create_index("matching_score")

    def get_next_sequence(self, collection_name):
        """Auto-increment integer IDs (like SQL primary keys)."""
        result = self.db.counters.find_one_and_update(
            {"_id": collection_name},
            {"$inc": {"seq": 1}},
            upsert=True,
            return_document=True,
        )
        return result["seq"]


# Global instance
mongo = MongoManager()


# ─── Helper: Convert ObjectId to string ───────────────────────────
def _str_id(doc):
    """Convert _id (ObjectId) to string for JSON serialization."""
    if doc and "_id" in doc:
        doc["_id"] = str(doc["_id"])
    return doc


# ═══════════════════════════════════════════════════════════════════
#  User — wraps a MongoDB document for Flask-Login compatibility
# ═══════════════════════════════════════════════════════════════════
class User(UserMixin):
    """Wraps a user document dict to satisfy Flask-Login interface."""

    def __init__(self, doc):
        self._doc = doc

    # Flask-Login needs get_id() → must return string
    def get_id(self):
        return str(self._doc["id"])

    @property
    def id(self):
        return self._doc["id"]

    @property
    def username(self):
        return self._doc.get("username")

    @property
    def email(self):
        return self._doc.get("email")

    @property
    def password_hash(self):
        return self._doc.get("password_hash")

    @property
    def role(self):
        return self._doc.get("role", "hr")

    def to_dict(self):
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "role": self.role,
        }

    # ── Static query helpers ──────────────────────────────────────
    @staticmethod
    def find_by_id(user_id):
        doc = mongo.db.users.find_one({"id": int(user_id)})
        return User(doc) if doc else None

    @staticmethod
    def find_by_username(username):
        doc = mongo.db.users.find_one({"username": username})
        return User(doc) if doc else None

    @staticmethod
    def find_by_email(email):
        doc = mongo.db.users.find_one({"email": email})
        return User(doc) if doc else None

    @staticmethod
    def count():
        return mongo.db.users.count_documents({})

    @staticmethod
    def create(username, email, password_hash, role="hr"):
        user_id = mongo.get_next_sequence("users")
        doc = {
            "id": user_id,
            "username": username,
            "email": email,
            "password_hash": password_hash,
            "role": role,
            "created_at": datetime.utcnow(),
        }
        mongo.db.users.insert_one(doc)
        return User(doc)


# ═══════════════════════════════════════════════════════════════════
#  JobDescription
# ═══════════════════════════════════════════════════════════════════
class JobDescription:
    """Helper class around the 'jobs' collection."""

    def __init__(self, doc):
        self._doc = doc

    @property
    def id(self):
        return self._doc["id"]

    @property
    def title(self):
        return self._doc.get("title")

    @property
    def description(self):
        return self._doc.get("description")

    @property
    def min_experience(self):
        return self._doc.get("min_experience", 0)

    @property
    def created_at(self):
        return self._doc.get("created_at", datetime.utcnow())

    def get_skills(self):
        return self._doc.get("required_skills", [])

    def set_skills(self, skills_list):
        self._doc["required_skills"] = skills_list

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "required_skills": self.get_skills(),
            "min_experience": self.min_experience,
            "created_at": self.created_at.isoformat() if isinstance(self.created_at, datetime) else str(self.created_at),
        }

    # ── Static query helpers ──────────────────────────────────────
    @staticmethod
    def find_by_id(job_id):
        doc = mongo.db.jobs.find_one({"id": int(job_id)})
        return JobDescription(doc) if doc else None

    @staticmethod
    def find_by_title(title):
        doc = mongo.db.jobs.find_one({"title": title})
        return JobDescription(doc) if doc else None

    @staticmethod
    def find_all(sort_field="created_at", sort_dir=-1):
        docs = mongo.db.jobs.find().sort(sort_field, sort_dir)
        return [JobDescription(d) for d in docs]

    @staticmethod
    def count():
        return mongo.db.jobs.count_documents({})

    @staticmethod
    def create(title, description, required_skills, min_experience, created_by):
        job_id = mongo.get_next_sequence("jobs")
        doc = {
            "id": job_id,
            "title": title,
            "description": description,
            "required_skills": required_skills,
            "min_experience": min_experience,
            "created_by": created_by,
            "created_at": datetime.utcnow(),
        }
        mongo.db.jobs.insert_one(doc)
        return JobDescription(doc)

    @staticmethod
    def update(job_id, update_fields):
        mongo.db.jobs.update_one({"id": int(job_id)}, {"$set": update_fields})

    @staticmethod
    def delete(job_id):
        mongo.db.jobs.delete_one({"id": int(job_id)})


# ═══════════════════════════════════════════════════════════════════
#  Resume
# ═══════════════════════════════════════════════════════════════════
class Resume:
    """Helper class around the 'resumes' collection."""

    def __init__(self, doc):
        self._doc = doc

    @property
    def id(self):
        return self._doc["id"]

    @property
    def filename(self):
        return self._doc.get("filename")

    @property
    def original_filename(self):
        return self._doc.get("original_filename")

    @property
    def file_type(self):
        return self._doc.get("file_type")

    @property
    def candidate_name(self):
        return self._doc.get("candidate_name")

    @property
    def email(self):
        return self._doc.get("email")

    @property
    def phone(self):
        return self._doc.get("phone")

    @property
    def raw_text(self):
        return self._doc.get("raw_text", "")

    @property
    def matching_score(self):
        return self._doc.get("matching_score", 0)

    @property
    def status(self):
        return self._doc.get("status", "pending")

    @property
    def job_id(self):
        return self._doc.get("job_id")

    @property
    def experience_years(self):
        return self._doc.get("experience_years", 0)

    @property
    def uploaded_at(self):
        return self._doc.get("uploaded_at", datetime.utcnow())

    def get_skills(self):
        return self._doc.get("skills", [])

    def get_education(self):
        return self._doc.get("education", [])

    def get_experience(self):
        return self._doc.get("experience_details", [])

    def get_suggestions(self):
        return self._doc.get("improvement_suggestions", [])

    def to_dict(self):
        uploaded = self.uploaded_at
        return {
            "id": self.id,
            "filename": self.original_filename,
            "stored_filename": self.filename,
            "file_type": self.file_type,
            "candidate_name": self.candidate_name or "Unknown",
            "email": self.email,
            "phone": self.phone,
            "skills": self.get_skills(),
            "education": self.get_education(),
            "experience_years": self.experience_years,
            "experience_details": self.get_experience(),
            "raw_text": (self.raw_text or "")[:8000],
            "matching_score": round(self.matching_score, 1),
            "status": self.status,
            "job_id": self.job_id,
            "uploaded_at": uploaded.isoformat() if isinstance(uploaded, datetime) else str(uploaded),
            "improvement_suggestions": self.get_suggestions(),
        }

    # ── Static query helpers ──────────────────────────────────────
    @staticmethod
    def find_by_id(resume_id):
        doc = mongo.db.resumes.find_one({"id": int(resume_id)})
        return Resume(doc) if doc else None

    @staticmethod
    def count(filters=None):
        return mongo.db.resumes.count_documents(filters or {})

    @staticmethod
    def find_all(filters=None, sort_field="matching_score", sort_dir=-1):
        docs = mongo.db.resumes.find(filters or {}).sort(sort_field, sort_dir)
        return [Resume(d) for d in docs]

    @staticmethod
    def create(**fields):
        resume_id = mongo.get_next_sequence("resumes")
        doc = {
            "id": resume_id,
            "uploaded_at": datetime.utcnow(),
            **fields,
        }
        mongo.db.resumes.insert_one(doc)
        return Resume(doc)

    @staticmethod
    def update(resume_id, update_fields):
        mongo.db.resumes.update_one({"id": int(resume_id)}, {"$set": update_fields})

    @staticmethod
    def delete(resume_id):
        mongo.db.resumes.delete_one({"id": int(resume_id)})

    @staticmethod
    def aggregate(pipeline):
        """Run a MongoDB aggregation pipeline on resumes collection."""
        return list(mongo.db.resumes.aggregate(pipeline))
