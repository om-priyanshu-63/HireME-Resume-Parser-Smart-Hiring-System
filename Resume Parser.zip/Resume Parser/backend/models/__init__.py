# models/__init__.py
from .database import mongo, User, JobDescription, Resume
