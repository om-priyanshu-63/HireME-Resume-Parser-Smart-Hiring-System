@echo off
echo ========================================
echo   HireME - Resume Parser ^& Smart Hiring
echo   Setup ^& Launch Script (MongoDB)
echo ========================================
echo.

:: Check MongoDB is running
echo [0/4] Checking MongoDB connection...
where mongosh >nul 2>&1
if errorlevel 1 (
    echo [INFO] mongosh not found in PATH. Make sure MongoDB is running on localhost:27017
) else (
    mongosh --eval "db.runCommand({ping:1})" --quiet >nul 2>&1
    if errorlevel 1 (
        echo WARNING: Could not connect to MongoDB on localhost:27017
        echo Please ensure MongoDB is installed and running.
        echo Download: https://www.mongodb.com/try/download/community
        pause
        exit /b 1
    ) else (
        echo [OK] MongoDB is reachable.
    )
)

cd /d "%~dp0backend"

echo [1/4] Creating Python virtual environment...
python -m venv venv
if errorlevel 1 (
    echo ERROR: Python not found. Please install Python 3.9+
    pause
    exit /b 1
)

echo [2/4] Activating virtual environment...
call venv\Scripts\activate.bat

echo [3/4] Installing dependencies...
pip install -r requirements.txt --quiet

echo [4/4] Downloading spaCy language model...
python -m spacy download en_core_web_sm --quiet

echo.
echo ========================================
echo   Setup Complete!
echo   Backend : MongoDB (localhost:27017)
echo   Database: hireme_db
echo   Starting server at http://localhost:5000
echo   Default Login: admin / admin123
echo ========================================
echo.
python app.py
pause
